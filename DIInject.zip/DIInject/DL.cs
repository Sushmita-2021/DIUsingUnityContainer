﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIInject
{
    public class DL : IProduct
    {
        public string Insertdata()
        {
            string result = "Dependency injection injected";
            Console.WriteLine(result);

            return result;
        }
    }
}
