﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace DIInject
{
    class Program
    {
        static void Main(string[] args)
        {

            UnityContainer container = new UnityContainer();
            container.RegisterType<IProduct, DL>();
            var obj = container.Resolve<BL>();
            obj.insert();
            Console.ReadLine();


        }
    }
}
